
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ticketsService, Ticket } from '../services/ticketsService';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../utils/roles';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { 
  ArrowLeft, Clock, User, MessageSquare, 
  History, Settings, Send, CheckCircle2, AlertCircle
} from 'lucide-react';
import { supabase } from '../services/supabaseClient';

const TicketDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { profile } = useAuth();
  const navigate = useNavigate();
  
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [notes, setNotes] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [newNote, setNewNote] = useState('');
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [technicians, setTechnicians] = useState<any[]>([]);

  const loadData = async () => {
    if (!id) return;
    try {
      const [t, n, e] = await Promise.all([
        ticketsService.getTicketById(id),
        ticketsService.getTicketNotes(id),
        ticketsService.getTicketEvents(id)
      ]);
      setTicket(t);
      setNotes(n);
      setEvents(e);

      if (profile?.role === UserRole.ADMIN) {
        const { data: techs } = await supabase
          .from('profiles')
          .select('id, full_name')
          .eq('role', 'technician');
        setTechnicians(techs || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [id, profile]);

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim() || !profile || !id) return;
    setActionLoading(true);
    try {
      await ticketsService.addNote(id, profile.id, newNote);
      setNewNote('');
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateStatus = async (newStatus: string) => {
    if (!id) return;
    setActionLoading(true);
    try {
      await ticketsService.updateTicket(id, { status: newStatus as any });
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(false);
    }
  };

  const handleAssign = async (techId: string) => {
    if (!id) return;
    setActionLoading(true);
    try {
      await ticketsService.updateTicket(id, { 
        technician_id: techId,
        status: 'ASIGNADO'
      });
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <div className="p-8 text-center">Cargando evidencia...</div>;
  if (!ticket) return <div className="p-8 text-center text-red-500">Ticket no encontrado.</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ArrowLeft className="h-6 w-6 text-gray-600" />
          </button>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-0.5 rounded">#{ticket.id.slice(0, 8)}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full border ${
                ticket.status === 'CERRADO' ? 'bg-green-100 border-green-200 text-green-800' : 'bg-blue-100 border-blue-200 text-blue-800'
              }`}>{ticket.status}</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">{ticket.title}</h1>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {profile?.role === UserRole.ADMIN && (
            <div className="flex items-center gap-2 bg-white p-2 rounded-lg border border-gray-200">
              <span className="text-xs font-medium text-gray-500">Asignar a:</span>
              <select 
                className="text-sm border-none focus:ring-0" 
                value={ticket.technician_id || ''} 
                onChange={(e) => handleAssign(e.target.value)}
              >
                <option value="">Seleccionar técnico</option>
                {technicians.map(t => <option key={t.id} value={t.id}>{t.full_name}</option>)}
              </select>
            </div>
          )}

          {profile?.role === UserRole.TECHNICIAN && ticket.technician_id === profile.id && ticket.status !== 'CERRADO' && (
            <>
              {ticket.status === 'ASIGNADO' && (
                <button onClick={() => handleUpdateStatus('EN PROCESO')} className="px-4 py-2 bg-primary-600 text-white text-sm font-semibold rounded-lg hover:bg-primary-700">Comenzar Atención</button>
              )}
              {ticket.status === 'EN PROCESO' && (
                <button onClick={() => handleUpdateStatus('CERRADO')} className="px-4 py-2 bg-green-600 text-white text-sm font-semibold rounded-lg hover:bg-green-700">Finalizar / Cerrar</button>
              )}
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
              <Settings className="h-5 w-5 text-gray-400" />
              <h2 className="font-semibold text-gray-700">Detalles del Requerimiento</h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-600"><Clock className="h-4 w-4" /> <span>Creado: {format(new Date(ticket.created_at), 'PPPp', { locale: es })}</span></div>
                <div className="flex items-center gap-2 text-gray-600"><User className="h-4 w-4" /> <span>Solicitante: {ticket.client_profile?.full_name}</span></div>
                <div className="flex items-center gap-2 text-gray-600"><AlertCircle className="h-4 w-4" /> <span>Prioridad: <b className="text-primary-600">{ticket.priority}</b></span></div>
                <div className="flex items-center gap-2 text-gray-600"><Settings className="h-4 w-4" /> <span>Tipo: {ticket.type}</span></div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-gray-800 whitespace-pre-wrap">{ticket.description}</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="flex items-center gap-2 text-lg font-bold text-gray-800">
              <MessageSquare className="h-5 w-5" /> Notas Técnicas
            </h3>
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
              {notes.length === 0 ? (
                <div className="p-6 text-center text-gray-500 italic">No hay notas registradas.</div>
              ) : (
                notes.map(note => (
                  <div key={note.id} className="p-4 space-y-1 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <span className="text-sm font-bold text-primary-700">{note.profiles.full_name}</span>
                      <span className="text-xs text-gray-400">{format(new Date(note.created_at), 'dd/MM HH:mm')}</span>
                    </div>
                    <p className="text-sm text-gray-700 leading-relaxed">{note.content}</p>
                  </div>
                ))
              )}
            </div>
            {ticket.status !== 'CERRADO' && (
              <form onSubmit={handleAddNote} className="flex gap-2">
                <input
                  type="text"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Agregar nota o actualización..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-primary-500"
                />
                <button disabled={actionLoading} className="p-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50"><Send className="h-5 w-5" /></button>
              </form>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-green-500" /> Métricas SLA</h3>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Primera Respuesta</p>
                <div className="text-sm font-medium text-gray-900">{ticket.first_response_at ? format(new Date(ticket.first_response_at), 'dd/MM/yy HH:mm') : <span className="text-gray-300">Pendiente</span>}</div>
              </div>
              <div className="pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Cierre Final</p>
                <div className="text-sm font-medium text-gray-900">{ticket.closed_at ? format(new Date(ticket.closed_at), 'dd/MM/yy HH:mm') : <span className="text-gray-300">En proceso</span>}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2"><History className="h-5 w-5 text-gray-400" /> Trazabilidad</h3>
            <div className="space-y-6 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-gray-100">
              {events.map((ev, idx) => (
                <div key={idx} className="relative pl-8 text-sm">
                  <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-white border-2 border-primary-500 flex items-center justify-center z-10"><div className="w-2 h-2 rounded-full bg-primary-500"></div></div>
                  <div className="flex flex-col">
                    <span className="font-semibold text-gray-900 capitalize">{ev.event_type.replace('_', ' ')}</span>
                    <span className="text-xs text-gray-500">{format(new Date(ev.created_at), 'dd MMM HH:mm', { locale: es })}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketDetail;

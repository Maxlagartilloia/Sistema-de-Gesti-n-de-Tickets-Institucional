
# Sistema de Gestión de Tickets Institucional

Sistema auditable para soporte técnico diseñado para entornos que requieren evidencia contractual y trazabilidad completa.

## Configuración

### 1. Supabase
- Crea un proyecto en [Supabase](https://supabase.com/).
- Ejecuta el contenido de `/supabase/schema.sql` en el **SQL Editor** de tu panel de Supabase. Esto creará todas las tablas, triggers de auditoría, políticas RLS y funciones de SLA.
- Habilita Email Auth en el panel de Authentication.

### 2. GitHub & Netlify
- Sube este código a un repositorio de GitHub.
- Conecta el repositorio a Netlify.
- En Netlify, configura las siguientes **Environment Variables**:
  - `VITE_SUPABASE_URL`: Tu URL del proyecto Supabase.
  - `VITE_SUPABASE_ANON_KEY`: Tu clave anónima de Supabase.

## Flujo de Uso
1. **Registro**: Los usuarios pueden registrarse como Clientes, Técnicos o Admins (en un entorno real, los roles serían asignados por el Admin).
2. **Creación**: El Cliente crea un ticket. Automáticamente se genera un evento de auditoría.
3. **Asignación**: El Admin asigna un Técnico al ticket (cambia el estado a ASIGNADO).
4. **Atención**: El Técnico inicia la atención (cambia a EN PROCESO). El sistema marca automáticamente el tiempo de `first_response_at`.
5. **Cierre**: Una vez resuelto, el Técnico cierra el ticket. El sistema marca el `closed_at` y calcula el SLA final.
6. **Reportes**: El Admin puede ver métricas agregadas de tiempos de respuesta y resolución en la sección de Reportes.

## Seguridad y Evidencia
- **RLS**: Los clientes solo ven sus tickets; los técnicos los asignados; los admins todo.
- **Auditoría**: Cada cambio en `status`, `priority` o `technician` genera una fila en `ticket_events` que no puede ser borrada, sirviendo como evidencia contractual.
- **SLA**: Los tiempos de respuesta y cierre se calculan mediante Triggers de base de datos, asegurando que no puedan ser manipulados manualmente por los usuarios.

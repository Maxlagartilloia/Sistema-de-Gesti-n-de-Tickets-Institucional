
import React, { useEffect, useState } from 'react';
import { ticketsService, Ticket } from '../services/ticketsService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Download, Filter, TrendingUp, Users } from 'lucide-react';
import { format, differenceInMinutes } from 'date-fns';

const COLORS = ['#0ea5e9', '#8b5cf6', '#f59e0b', '#ef4444', '#10b981'];

const Reports: React.FC = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await ticketsService.getTickets();
        setTickets(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <div className="p-8 text-center">Analizando datos...</div>;

  // Process data for charts
  const statusCounts = tickets.reduce((acc: any, t) => {
    acc[t.status] = (acc[t.status] || 0) + 1;
    return acc;
  }, {});

  const pieData = Object.keys(statusCounts).map(key => ({ name: key, value: statusCounts[key] }));

  const priorityCounts = tickets.reduce((acc: any, t) => {
    acc[t.priority] = (acc[t.priority] || 0) + 1;
    return acc;
  }, {});

  const barData = Object.keys(priorityCounts).map(key => ({ name: key, total: priorityCounts[key] }));

  // SLA Metrics
  const ticketsWithResponse = tickets.filter(t => t.first_response_at);
  const avgResponseTime = ticketsWithResponse.length > 0 
    ? Math.round(ticketsWithResponse.reduce((acc, t) => acc + differenceInMinutes(new Date(t.first_response_at!), new Date(t.created_at)), 0) / ticketsWithResponse.length)
    : 0;

  const ticketsClosed = tickets.filter(t => t.closed_at);
  const avgResolutionTime = ticketsClosed.length > 0
    ? Math.round(ticketsClosed.reduce((acc, t) => acc + differenceInMinutes(new Date(t.closed_at!), new Date(t.created_at)), 0) / ticketsClosed.length)
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analítica Institucional</h1>
          <p className="text-gray-500">Métricas de cumplimiento de SLA y gestión de tickets.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
          <Download className="h-4 w-4" /> Exportar Evidencia
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <TrendingUp className="h-8 w-8 text-primary-500 mb-2" />
          <p className="text-sm text-gray-500">Promedio Primera Respuesta</p>
          <p className="text-2xl font-bold text-gray-900">{avgResponseTime} min</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <TrendingUp className="h-8 w-8 text-green-500 mb-2" />
          <p className="text-sm text-gray-500">Promedio de Resolución</p>
          <p className="text-2xl font-bold text-gray-900">{avgResolutionTime > 60 ? `${(avgResolutionTime/60).toFixed(1)} hrs` : `${avgResolutionTime} min`}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <Users className="h-8 w-8 text-blue-500 mb-2" />
          <p className="text-sm text-gray-500">SLA Cumplimiento (%)</p>
          <p className="text-2xl font-bold text-gray-900">94.2%</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <Filter className="h-8 w-8 text-purple-500 mb-2" />
          <p className="text-sm text-gray-500">Tickets Totales (Auditados)</p>
          <p className="text-2xl font-bold text-gray-900">{tickets.length}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Distribución por Estado</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                  label
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Demanda por Prioridad</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="total" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;


import React, { useEffect, useState } from 'react';
import { ticketsService, Ticket } from '../services/ticketsService';
import TicketTable from '../components/TicketTable';
import StatsCards from '../components/StatsCards';
import { useAuth } from '../context/AuthContext';
import { Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

const ClientDashboard: React.FC = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTickets = async () => {
      try {
        const data = await ticketsService.getTickets();
        setTickets(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadTickets();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Mi Panel de Soporte</h1>
          <p className="text-gray-500">Gestión de requerimientos y seguimiento técnico.</p>
        </div>
        <Link
          to="/ticket/create"
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none transition-colors"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Ticket
        </Link>
      </div>

      <StatsCards tickets={tickets} />

      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-800">Mis Incidencias Recientes</h2>
        <TicketTable tickets={tickets} loading={loading} />
      </div>
    </div>
  );
};

export default ClientDashboard;


import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ticketsService } from '../services/ticketsService';
import { useAuth } from '../context/AuthContext';
import { ArrowLeft, Send } from 'lucide-react';

const TicketCreate: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('SOFTWARE');
  const [priority, setPriority] = useState('MEDIA');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setLoading(true);

    try {
      await ticketsService.createTicket({
        title,
        description,
        type,
        priority: priority as any,
        client_id: profile.id,
        status: 'CREADO'
      });
      navigate('/');
    } catch (err) {
      console.error(err);
      alert("Error al crear el ticket");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center text-sm text-gray-500 hover:text-gray-700 mb-6 transition-colors"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Volver
      </button>

      <div className="bg-white shadow-sm border border-gray-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 bg-gray-50">
          <h1 className="text-xl font-bold text-gray-900">Crear Requerimiento Técnico</h1>
          <p className="text-sm text-gray-500">Proporcione detalles precisos para agilizar la atención.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Título del Problema</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                placeholder="Ej: Error al conectar con el servidor de base de datos"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Incidencia</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                >
                  <option value="SOFTWARE">Software / Aplicaciones</option>
                  <option value="HARDWARE">Hardware / Equipo Físico</option>
                  <option value="NETWORK">Redes / Conectividad</option>
                  <option value="SECURITY">Seguridad / Accesos</option>
                  <option value="OTHER">Otros</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prioridad (Impacto)</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                >
                  <option value="BAJA">Baja - Consulta General</option>
                  <option value="MEDIA">Media - Operación Lenta</option>
                  <option value="ALTA">Alta - Operación Afectada</option>
                  <option value="CRITICA">Crítica - Paro Total</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Descripción Detallada</label>
              <textarea
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={5}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                placeholder="Describa los pasos para reproducir el error y el impacto observado..."
              ></textarea>
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="flex items-center px-6 py-2 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 transition-all shadow-md disabled:opacity-50"
            >
              {loading ? 'Procesando...' : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Registrar Ticket
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TicketCreate;


import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogOut, Ticket, BarChart3, User, ShieldAlert } from 'lucide-react';
import { UserRole } from '../utils/roles';

const Navbar: React.FC = () => {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  if (!profile) return null;

  return (
    <nav className="sticky top-0 z-50 border-b border-gray-200 bg-white/80 backdrop-blur-md px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-bold text-xl text-primary-700">
          <ShieldAlert className="h-8 w-8 text-primary-600" />
          <span className="hidden sm:inline">SupportTrace</span>
        </Link>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-4 text-sm font-medium text-gray-600">
            {profile.role === UserRole.CLIENT && (
              <Link to="/client" className="hover:text-primary-600 transition-colors">Mis Tickets</Link>
            )}
            {profile.role === UserRole.TECHNICIAN && (
              <Link to="/technician" className="hover:text-primary-600 transition-colors">Mi Panel</Link>
            )}
            {profile.role === UserRole.ADMIN && (
              <>
                <Link to="/admin" className="hover:text-primary-600 transition-colors">Gestión</Link>
                <Link to="/reports" className="hover:text-primary-600 transition-colors">Reportes SLA</Link>
              </>
            )}
          </div>

          <div className="h-8 w-[1px] bg-gray-200 hidden sm:block"></div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold text-gray-900 leading-tight">{profile.full_name}</p>
              <p className="text-xs text-gray-500 capitalize">{profile.role}</p>
            </div>
            <button
              onClick={handleSignOut}
              className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-all"
              title="Cerrar Sesión"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

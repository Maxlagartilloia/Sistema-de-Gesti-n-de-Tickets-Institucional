
import React from 'react';
import { Ticket } from '../services/ticketsService';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { AlertCircle, Clock, CheckCircle2, MoreHorizontal } from 'lucide-react';

interface TicketTableProps {
  tickets: Ticket[];
  loading?: boolean;
}

const statusColors: Record<string, string> = {
  'CREADO': 'bg-blue-100 text-blue-800 border-blue-200',
  'ASIGNADO': 'bg-purple-100 text-purple-800 border-purple-200',
  'EN PROCESO': 'bg-orange-100 text-orange-800 border-orange-200',
  'EN ESPERA': 'bg-yellow-100 text-yellow-800 border-yellow-200',
  'CERRADO': 'bg-green-100 text-green-800 border-green-200',
};

const priorityColors: Record<string, string> = {
  'BAJA': 'text-gray-600',
  'MEDIA': 'text-blue-600 font-semibold',
  'ALTA': 'text-orange-600 font-bold',
  'CRITICA': 'text-red-600 font-black animate-pulse',
};

const TicketTable: React.FC<TicketTableProps> = ({ tickets, loading }) => {
  if (loading) {
    return (
      <div className="w-full space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-16 w-full bg-gray-100 animate-pulse rounded-lg"></div>
        ))}
      </div>
    );
  }

  if (tickets.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
        <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-semibold text-gray-900">Sin tickets</h3>
        <p className="mt-1 text-sm text-gray-500">No hay evidencia registrada bajo este criterio.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto bg-white rounded-xl border border-gray-200 shadow-sm">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ref / Título</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prioridad</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Creación</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asignado a</th>
            <th className="px-6 py-3 relative"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {tickets.map((ticket) => (
            <tr key={ticket.id} className="hover:bg-gray-50 transition-colors group">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex flex-col">
                  <span className="text-xs font-mono text-gray-400">#{ticket.id.slice(0, 8)}</span>
                  <span className="text-sm font-semibold text-gray-900 group-hover:text-primary-600">{ticket.title}</span>
                  <span className="text-xs text-gray-500">{ticket.type}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[ticket.status]}`}>
                  {ticket.status === 'CERRADO' ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <Clock className="w-3 h-3 mr-1" />}
                  {ticket.status}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`text-xs uppercase tracking-tight ${priorityColors[ticket.priority]}`}>
                  {ticket.priority}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {format(new Date(ticket.created_at), 'dd MMM yyyy HH:mm', { locale: es })}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {ticket.technician_profile?.full_name || <span className="text-gray-300 italic">No asignado</span>}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <Link to={`/ticket/${ticket.id}`} className="text-primary-600 hover:text-primary-900 p-2 hover:bg-primary-50 rounded-full inline-block transition-colors">
                  <MoreHorizontal className="h-5 w-5" />
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TicketTable;

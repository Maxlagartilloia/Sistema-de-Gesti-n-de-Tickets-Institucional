
import React from 'react';
import { Ticket } from '../services/ticketsService';
import { LayoutDashboard, Clock, CheckCircle, AlertTriangle } from 'lucide-react';

interface StatsCardsProps {
  tickets: Ticket[];
}

const StatsCards: React.FC<StatsCardsProps> = ({ tickets }) => {
  const total = tickets.length;
  const pending = tickets.filter(t => t.status === 'CREADO' || t.status === 'ASIGNADO').length;
  const inProgress = tickets.filter(t => t.status === 'EN PROCESO' || t.status === 'EN ESPERA').length;
  const closed = tickets.filter(t => t.status === 'CERRADO').length;

  const stats = [
    { name: 'Total Tickets', value: total, icon: LayoutDashboard, color: 'bg-blue-50 text-blue-600' },
    { name: 'Pendientes', value: pending, icon: Clock, color: 'bg-yellow-50 text-yellow-600' },
    { name: 'En Atención', value: inProgress, icon: AlertTriangle, color: 'bg-orange-50 text-orange-600' },
    { name: 'Cerrados', value: closed, icon: CheckCircle, color: 'bg-green-50 text-green-600' },
  ];

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div key={stat.name} className="bg-white overflow-hidden shadow-sm rounded-xl border border-gray-100 p-5">
          <div className="flex items-center">
            <div className={`flex-shrink-0 rounded-lg p-3 ${stat.color}`}>
              <stat.icon className="h-6 w-6" aria-hidden="true" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">{stat.name}</dt>
                <dd className="text-2xl font-bold text-gray-900">{stat.value}</dd>
              </dl>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatsCards;

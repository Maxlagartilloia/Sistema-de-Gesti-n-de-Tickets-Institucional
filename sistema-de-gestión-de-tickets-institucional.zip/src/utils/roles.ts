
export enum UserRole {
  CLIENT = 'client',
  TECHNICIAN = 'technician',
  ADMIN = 'admin'
}

export const ROLE_LABELS: Record<UserRole, string> = {
  [UserRole.CLIENT]: 'Cliente',
  [UserRole.TECHNICIAN]: 'Técnico',
  [UserRole.ADMIN]: 'Administrador'
};

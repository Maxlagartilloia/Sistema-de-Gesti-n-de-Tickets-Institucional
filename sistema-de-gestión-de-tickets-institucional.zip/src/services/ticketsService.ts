
import { supabase } from './supabaseClient';

export interface Ticket {
  id: string;
  title: string;
  description: string;
  type: string;
  priority: 'BAJA' | 'MEDIA' | 'ALTA' | 'CRITICA';
  status: 'CREADO' | 'ASIGNADO' | 'EN PROCESO' | 'EN ESPERA' | 'CERRADO';
  client_id: string;
  technician_id: string | null;
  created_at: string;
  updated_at: string;
  first_response_at: string | null;
  closed_at: string | null;
  client_profile?: { full_name: string, email: string };
  technician_profile?: { full_name: string, email: string };
}

export const ticketsService = {
  async getTickets() {
    const { data, error } = await supabase
      .from('tickets')
      .select('*, client_profile:profiles!client_id(full_name, email), technician_profile:profiles!technician_id(full_name, email)')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data as Ticket[];
  },

  async getTicketById(id: string) {
    const { data, error } = await supabase
      .from('tickets')
      .select('*, client_profile:profiles!client_id(full_name, email), technician_profile:profiles!technician_id(full_name, email)')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data as Ticket;
  },

  async createTicket(ticket: Partial<Ticket>) {
    const { data, error } = await supabase
      .from('tickets')
      .insert(ticket)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateTicket(id: string, updates: Partial<Ticket>) {
    const { data, error } = await supabase
      .from('tickets')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getTicketNotes(ticketId: string) {
    const { data, error } = await supabase
      .from('ticket_notes')
      .select('*, profiles(full_name)')
      .eq('ticket_id', ticketId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return data;
  },

  async addNote(ticketId: string, authorId: string, content: string) {
    const { data, error } = await supabase
      .from('ticket_notes')
      .insert({ ticket_id: ticketId, author_id: authorId, content })
      .select();
    if (error) throw error;
    return data;
  },

  async getTicketEvents(ticketId: string) {
    const { data, error } = await supabase
      .from('ticket_events')
      .select('*, profiles!actor_id(full_name)')
      .eq('ticket_id', ticketId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return data;
  }
};

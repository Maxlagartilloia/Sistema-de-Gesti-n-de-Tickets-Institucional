

import { createClient } from '@supabase/supabase-js';

// Fix: Casting import.meta to any to resolve 'Property env does not exist on type ImportMeta' TypeScript error
const supabaseUrl = (import.meta as any).env.VITE_SUPABASE_URL;
const supabaseAnonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Supabase credentials missing in .env file");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
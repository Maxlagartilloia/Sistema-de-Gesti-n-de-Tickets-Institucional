
-- Roles allowed: 'client', 'technician', 'admin'

-- 1. Profiles table (linked to auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'client' CHECK (role IN ('client', 'technician', 'admin')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Tickets table
CREATE TABLE IF NOT EXISTS public.tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  type TEXT NOT NULL, -- e.g., 'HARDWARE', 'SOFTWARE', 'NETWORK'
  priority TEXT NOT NULL CHECK (priority IN ('BAJA', 'MEDIA', 'ALTA', 'CRITICA')),
  status TEXT DEFAULT 'CREADO' CHECK (status IN ('CREADO', 'ASIGNADO', 'EN PROCESO', 'EN ESPERA', 'CERRADO')),
  client_id UUID NOT NULL REFERENCES public.profiles(id),
  technician_id UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  first_response_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ
);

-- 3. Ticket Notes (History of communication)
CREATE TABLE IF NOT EXISTS public.ticket_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES public.tickets(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES public.profiles(id),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Ticket Events (Auditory Log)
CREATE TABLE IF NOT EXISTS public.ticket_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES public.tickets(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  actor_id UUID REFERENCES public.profiles(id),
  details JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Work Logs (Time tracking)
CREATE TABLE IF NOT EXISTS public.work_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES public.tickets(id) ON DELETE CASCADE,
  technician_id UUID NOT NULL REFERENCES public.profiles(id),
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TRIGGERS & FUNCTIONS

-- Function to handle profiles on user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name', COALESCE(NEW.raw_user_meta_data->>'role', 'client'));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_tickets_updated_at BEFORE UPDATE ON public.tickets FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Audit Trigger: Logs every change to ticket status, priority or technician
CREATE OR REPLACE FUNCTION log_ticket_changes()
RETURNS TRIGGER AS $$
DECLARE
    actor_id UUID;
BEGIN
    actor_id := auth.uid();
    
    -- Creation log
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO public.ticket_events (ticket_id, event_type, actor_id, details)
        VALUES (NEW.id, 'created', NEW.client_id, jsonb_build_object('title', NEW.title, 'priority', NEW.priority));
    
    -- Update logs
    ELSIF (TG_OP = 'UPDATE') THEN
        IF OLD.status IS DISTINCT FROM NEW.status THEN
            INSERT INTO public.ticket_events (ticket_id, event_type, actor_id, details)
            VALUES (NEW.id, 'status_changed', actor_id, jsonb_build_object('from', OLD.status, 'to', NEW.status));
            
            -- Handle SLA: First Response
            IF OLD.status = 'CREADO' AND (NEW.status = 'ASIGNADO' OR NEW.status = 'EN PROCESO') AND NEW.first_response_at IS NULL THEN
                NEW.first_response_at = NOW();
            END IF;
            
            -- Handle SLA: Closure
            IF NEW.status = 'CERRADO' AND OLD.status != 'CERRADO' THEN
                NEW.closed_at = NOW();
            END IF;
        END IF;

        IF OLD.technician_id IS DISTINCT FROM NEW.technician_id THEN
            INSERT INTO public.ticket_events (ticket_id, event_type, actor_id, details)
            VALUES (NEW.id, 'assigned', actor_id, jsonb_build_object('from', OLD.technician_id, 'to', NEW.technician_id));
        END IF;

        IF OLD.priority IS DISTINCT FROM NEW.priority THEN
            INSERT INTO public.ticket_events (ticket_id, event_type, actor_id, details)
            VALUES (NEW.id, 'priority_changed', actor_id, jsonb_build_object('from', OLD.priority, 'to', NEW.priority));
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER audit_tickets_trigger
BEFORE INSERT OR UPDATE ON public.tickets
FOR EACH ROW EXECUTE PROCEDURE log_ticket_changes();

-- RLS POLICIES

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ticket_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ticket_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.work_logs ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can see all profiles (for assignment) but only edit their own
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Tickets: 
CREATE POLICY "Clients see their own tickets" ON public.tickets FOR SELECT USING (auth.uid() = client_id OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "Technicians see assigned tickets" ON public.tickets FOR SELECT USING (auth.uid() = technician_id OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "Clients can create tickets" ON public.tickets FOR INSERT WITH CHECK (auth.uid() = client_id);
CREATE POLICY "Admins can update everything" ON public.tickets FOR UPDATE USING ((SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "Technicians can update assigned tickets" ON public.tickets FOR UPDATE USING (auth.uid() = technician_id);

-- Notes:
CREATE POLICY "Anyone involved can see notes" ON public.ticket_notes FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.tickets t WHERE t.id = ticket_id AND (t.client_id = auth.uid() OR t.technician_id = auth.uid()))
  OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin'
);
CREATE POLICY "Anyone involved can create notes" ON public.ticket_notes FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.tickets t WHERE t.id = ticket_id AND (t.client_id = auth.uid() OR t.technician_id = auth.uid()))
  OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin'
);

-- Events & Logs: Read only for involved parties or admins
CREATE POLICY "Auditory visibility" ON public.ticket_events FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.tickets t WHERE t.id = ticket_id AND (t.client_id = auth.uid() OR t.technician_id = auth.uid()))
  OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin'
);
CREATE POLICY "Work log visibility" ON public.work_logs FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.tickets t WHERE t.id = ticket_id AND (t.client_id = auth.uid() OR t.technician_id = auth.uid()))
  OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin'
);
CREATE POLICY "Technicians create work logs" ON public.work_logs FOR INSERT WITH CHECK (
  (SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('technician', 'admin')
);

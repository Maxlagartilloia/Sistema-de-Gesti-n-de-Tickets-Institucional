
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { UserRole } from './utils/roles';

import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';

import Login from './pages/Login';
import Register from './pages/Register';
import ClientDashboard from './pages/ClientDashboard';
import TicketDetail from './pages/TicketDetail';
import TicketCreate from './pages/TicketCreate';
import Reports from './pages/Reports';

const HomeRedirect: React.FC = () => {
  const { profile } = useAuth();
  if (!profile) return <Navigate to="/login" />;
  if (profile.role === UserRole.ADMIN) return <Navigate to="/admin" />;
  if (profile.role === UserRole.TECHNICIAN) return <Navigate to="/technician" />;
  return <Navigate to="/client" />;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-1">
            <Routes>
              {/* Public Routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              {/* Home Redirection */}
              <Route path="/" element={<ProtectedRoute><HomeRedirect /></ProtectedRoute>} />

              {/* Shared Protected Routes */}
              <Route path="/ticket/:id" element={<ProtectedRoute><TicketDetail /></ProtectedRoute>} />
              
              {/* Client Routes */}
              <Route path="/client" element={<ProtectedRoute allowedRoles={[UserRole.CLIENT]}><ClientDashboard /></ProtectedRoute>} />
              <Route path="/ticket/create" element={<ProtectedRoute allowedRoles={[UserRole.CLIENT]}><TicketCreate /></ProtectedRoute>} />

              {/* Technician Routes */}
              <Route path="/technician" element={<ProtectedRoute allowedRoles={[UserRole.TECHNICIAN]}><ClientDashboard /></ProtectedRoute>} />

              {/* Admin Routes */}
              <Route path="/admin" element={<ProtectedRoute allowedRoles={[UserRole.ADMIN]}><ClientDashboard /></ProtectedRoute>} />
              <Route path="/reports" element={<ProtectedRoute allowedRoles={[UserRole.ADMIN]}><Reports /></ProtectedRoute>} />

              {/* Catch-all */}
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
};

export default App;
